// This file is deprecated after migrating to Redux. Please import useSelector/useDispatch directly.
export default function UseAuth() {
    throw new Error('UseAuth has been removed. Use Redux hooks instead.');
}